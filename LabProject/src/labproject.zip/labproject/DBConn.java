package labproject;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

/**
 *
 * @author mddilshad
 * 
 */
public class DBConn {
    Connection con;
    PreparedStatement statement;
    Statement stmt;
    boolean flag = false;
    DBConn(){
        flag = false;
        con = null;
        statement = null;
        stmt = null;
    }
    
    void reset(){
        flag = false;
        con = null;
        statement = null;
        stmt = null;
    }
    void createConn(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://192.168.10.10:3306/mddilsh3_hostel", "homestead", "secret");
            System.out.println("Database connection successful");
            flag = true;
        }
        catch(ClassNotFoundException | SQLException ex){
            System.out.println("database not connenected");
        }
    }
    
    boolean adminLoginCheck(String id,String password){
       createConn();
        boolean f = false;
        try{
            String query = "select id,password from mddilsh3_hostel.admin";
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                if( password.equals(rs.getString("password"))){
                    if ( Integer.toString(rs.getInt("id")).equals(id)) {
                        f = true;
                    }
                }
            }
        }
        catch(SQLException ex){
            System.out.println("database not connenected");
        }
        reset();
        return f;
    }
    
    
    boolean customerLoginCheck(String gmail,String password){
        createConn();
        boolean f = false;
        try{
            String query = "select email,password from mddilsh3_hostel.customer";
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                if(gmail.equals(rs.getString("email")) && password.equals(rs.getString("password"))){
                    f = true;
                }
            }
        }
        catch(SQLException ex){
            System.out.println("database not connenected");
        }
        reset();
        return f;
    }
    
    void insertIntoCusTable(String name,String gmail,String password){
        createConn();
        String query = "insert into mddilsh3_hostel.customer(name,password,email)values('"+name+"','"+password+"','"+gmail+"');";
        if(flag == true){
            try{
                stmt = con.createStatement();
                stmt.executeUpdate(query);
            }
            catch(SQLException e){
                //e.printStackTrace();
            }
        }
        reset();
    }
    
    /*
    public static void main(String[] args){
        new DBConn().createConn();
    }
    */

    
}
