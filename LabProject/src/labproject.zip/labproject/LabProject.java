package labproject;
/**
 *
 * @author mddilshad
 * 
 */

public class LabProject {
    
    public static void main(String[] args) {
        FormFlow.runForm(new LoginForm());
        //new DBConn().insertIntoCusTable();
        
    }
    
}
